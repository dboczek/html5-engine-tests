The Official Specs for CommonJS
