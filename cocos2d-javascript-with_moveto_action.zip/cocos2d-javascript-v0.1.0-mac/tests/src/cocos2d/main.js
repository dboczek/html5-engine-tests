window.onload = function() {
    document.body.innerHTML = '<h1>cocos2d-javascript tests</h1>' +
                              '<ul>' +
                                  '<li>Sprites</li>' +
                                  '<li>TileMaps</li>' +
                                  '<li>commonJS</li>' +
                              '</ul>';
};
